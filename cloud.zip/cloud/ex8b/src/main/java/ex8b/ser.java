package ex8b;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/add")
public class ser extends HttpServlet {
	public void service(HttpServletRequest req,HttpServletResponse res)throws IOException{
 int a=Integer.parseInt(req.getParameter("n1"));
 int b=Integer.parseInt(req.getParameter("n2"));
 int c=a+b;
 PrintWriter out=res.getWriter();
 out.println("add"+c);
}
}