package Bank_application;
class Animal
{
	void get()
	{
		System.out.println("So many animals in this world");
	}
}
class Dog extends Animal
{
	void put()
	{
		System.out.println("Dog is a domestic animal");
	}
}
class Cat extends Animal
{
	void gets()
	{
		System.out.println("I love DOG");
	}
}
public class HierarchicalInheritance {

	public static void main(String[] args) {
		Cat c=new Cat();
		c.gets();
		c.get();

	}

}
