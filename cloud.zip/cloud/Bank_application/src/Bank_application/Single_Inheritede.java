package Bank_application;
class Fruits
{
	void eat()
	{
		System.out.println("All fruits are very healthy");
	}
}
class Vegetables extends Fruits
{
     void hate()
     {
    	 System.out.println("I hate bitter gourd");
     }
}

public class Single_Inheritede {

	public static void main(String[] args) {
		Vegetables v=new Vegetables();
		v.hate();
		v.eat();
	}

}
