package Bank_application;
class Area
{
	void draw()
	{
		System.out.println("Draw anything");
	}
}
class Circle extends Area
{
	void draw()
	{
		System.out.println("Area of Circle pie r^2");
	}
}
class Square extends Area
{
	void draw()
	{
		System.out.println("Area of Square a^2");
	}
}
public class RuntimePolymorphism {
	public static void main(String[] args) {
		Area a;
		a=new Circle();
		a.draw();
		a=new Square();
		a.draw();
	}
}
