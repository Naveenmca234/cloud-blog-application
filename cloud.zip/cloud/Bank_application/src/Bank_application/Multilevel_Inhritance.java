package Bank_application;
class Job
{
	void get()
	{
		System.out.println("So many jobs are available");
	}
}
class PrivateJob extends Job
{
	void put()
	{
		System.out.println("WIPRO Company");
	}
}
class GovtJob extends PrivateJob
{
	void gets()
	{
		System.out.println("Group exam is the entry point of GovtJob");
	}
}
public class Multilevel_Inhritance {

	public static void main(String[] args) {
		GovtJob g=new GovtJob();
		g.gets();
		g.put();
		g.get();
	}

}
