package Bank_application;
class Loader
{
static int add(int x,int y)
{
return x+y;
}
static int add(int x,int y,int z)
{
return x+y+z;
}
static double add(double x)
{
return x;
}
}

public class Overloading {

	public static void main(String[] args) {
		System.out.println("Int x+y : "+Loader.add(14,14));
		System.out.println("Int x+y+z : "+Loader.add(121,121,121));
		System.out.println("Double x : "+Loader.add(13));
	}

}
