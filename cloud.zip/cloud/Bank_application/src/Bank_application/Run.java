package Bank_application;

public class Run {
	  int a= 10;  
      int b=12;  
      int result = a+b;  
      System.out.println("Thread started running..");  
      System.out.println("Sum of two numbers is: "+ result); 
}
public static void main(String args[]) {
		// TODO Auto-generated method stub
	ThreadExample1 t1 = new  ThreadExample1();  
    t1.start();  
}

}
