package Bank_application;
interface Bank{
	float interest();
}
class KVB implements Bank
{
	public float interest() {
		return 9.8f;
	}
}
class SBI implements Bank
{
	public float interest()
	{
		return 19.5f;
	}
}

public class Inter {

	public static void main(String[] args) {
		Bank b=new KVB();
		System.out.println("Interest : "+b.interest());
	}

}
