package demo;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class demo {

    public static void main(String[] args) {
        // JDBC Connection
        try {
            // Load the JDBC driver (e.g., for MySQL)
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Set your database connection details
            String url = "jdbc:mysql://localhost:3306/mydatabase"; // Adjust URL for MySQL
            String user = "root"; // MySQL username
            String password = "password"; // MySQL password

            // Establish the connection
            Connection connection = DriverManager.getConnection(url, user, password);

            // Create a statement
            Statement statement = connection.createStatement();

            // Execute a sample query (you can replace this with your own SQL)
            String query = "SELECT * FROM employees";
            statement.executeQuery(query);

            // Close the resources
            statement.close();
            connection.close();
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }

        // Hibernate Configuration
        Configuration hibernateConfig = new Configuration()
                .setProperty("hibernate.connection.driver_class", "com.mysql.cj.jdbc.Driver")
                .setProperty("hibernate.connection.url", "jdbc:mysql://localhost:3306/mydatabase")
                .setProperty("hibernate.connection.username", "root")
                .setProperty("hibernate.connection.password", "password")
                .setProperty("hibernate.dialect", "org.hibernate.dialect.MySQLDialect")
                .addAnnotatedClass(Employee.class); // Replace with your entity class

        // Create a session factory
        SessionFactory sessionFactory = hibernateConfig.buildSessionFactory();

        // Create a session
        try (Session session = sessionFactory.openSession()) {
            // Perform database operations using Hibernate
            // Example: session.save(new Employee("John Doe", "Software Engineer"));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}